# Версия модуля
__version__ = '0.1.0'

# Конфигурация приложения
default_app_config = 'logs.apps.LogsConfig'
